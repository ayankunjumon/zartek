
<?php $__env->startSection('title','MY CONTACTS'); ?>
<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <table id="lis">
            <thead>
                
                <tr><th>Id</th>
                <th>Name</th>
<th>Address</th>
<th>Email</th>
<th>PhoneOne</th>
<th>Phonetwo</th>

                    
                    
                    <th>Contactpics</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">
    $(function () {
        var table = $('#lis').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('mycontacts')); ?>",
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },
                {
                    data: 'Name',
                    name: 'Name'
                },
                {
                    data: 'Address',
                    name: 'Address'
                },
                
                
                {
                    data: 'Email',
                    name: 'ESmail'
                },
                
                {
                    data: 'Phonenumberone',
                    name: 'Phonenumberone'
                },

                {
                    data: 'Phonenumbertwo',
                    name: 'Phonenumbertwo'
                },
                
                
                {
                    data: 'contactpics',
                    name: 'contactpics',
                   
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: true,
                    searchable: true
                },
            ]
        });

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('usermaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\classes\machinetest\resources\views/mycontacts.blade.php ENDPATH**/ ?>