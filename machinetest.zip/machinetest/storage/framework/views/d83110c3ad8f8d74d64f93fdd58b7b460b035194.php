
<?php $__env->startSection('title','WELCOME TO MACHINE TEST'); ?>
<?php echo $__env->make('usermaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\classes\machinetest\resources\views/userdashboard.blade.php ENDPATH**/ ?>