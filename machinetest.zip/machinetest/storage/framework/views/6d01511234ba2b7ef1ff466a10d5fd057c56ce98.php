<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
</style>
<link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
<h4><a href="<?php echo e(route('myprofile')); ?>">My profile</a>
<a href="<?php echo e(route('mycontacts')); ?>">My Contacts</a>

<a href="<?php echo e(route('contact.create')); ?>">Add Contacts</a>

<a href="/">logout</a></h4>
<br><h2>
<?php echo $__env->yieldContent('title'); ?>
</h2>
<?php echo $__env->yieldContent('content'); ?>
</body></html><?php /**PATH E:\classes\machinetest\resources\views/usermaster.blade.php ENDPATH**/ ?>