
<?php $__env->startSection('title','MY PROFILE'); ?>
<?php $__env->startSection('content'); ?>

<form method="post" action="<?php echo e(route('register.store')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>
   
    
    <img src="storage/<?php echo e($data[0]->profilepic); ?>" width="100px" height="100px">

    Name<input type="text" name="name" required value="<?php echo e(old('name',$data[0]->Name)); ?>" readonly><br>
Email<input type="email" name="email" required value="<?php echo e(old('email',$data[0]->Email)); ?>"readonly><br>
Phone Number<input type="text" name="phonenumber" value="<?php echo e(old('phonenumber',$data[0]->Phonenumber)); ?>"readonly><br>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usermaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\classes\machinetest\resources\views/myprofile.blade.php ENDPATH**/ ?>