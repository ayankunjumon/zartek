
<?php $__env->startSection('title','ADMIN DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\classes\machinetest\resources\views/admindashboard.blade.php ENDPATH**/ ?>