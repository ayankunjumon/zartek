<link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
<div class="container"><form method="post" action="<?php echo e(route('register.validatelogin')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>

   User Name <input type="text" name="username"><br>
  Password <input type="password" name="password">
  <input type="submit" value="login" name="login"><input type="reset" value="cancel">
</form>
<a href="<?php echo e(route('register.create')); ?>"> Register Now</a>
</div><?php /**PATH E:\classes\machinetest\resources\views/login.blade.php ENDPATH**/ ?>