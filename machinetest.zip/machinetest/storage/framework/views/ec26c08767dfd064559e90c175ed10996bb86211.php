<h4><a href="<?php echo e(route('register.index')); ?>">Users List</a>
<a href="<?php echo e(route('contact.index')); ?>">Contacts list</a>



<a href="/">logout</a></h4>
<br><h2>
<?php echo $__env->yieldContent('title'); ?>
</h2>
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH E:\classes\machinetest\resources\views/adminmaster.blade.php ENDPATH**/ ?>