<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InterviewcontactController;
use App\Http\Controllers\UseregisterController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});

Route::resource('/contact',InterviewcontactController::class);
Route::resource('/register',UseregisterController::class);
Route::get('/login', [UseregisterController::class, 'index'])->name('login');
Route::get('/userdashboard', [UseregisterController::class, 'userdashboard'])->name('userdashboard');
Route::get('/admindashboard', [UseregisterController::class, 'admindashboard'])->name('admindashboard');
Route::get('/logout', [UseregisterController::class, 'logout'])->name('logout');
Route::get('/myprofile', [UseregisterController::class, 'myprofile'])->name('myprofile');
Route::get('/mycontacts', [InterviewcontactController::class, 'mycontacts'])->name('mycontacts');
Route::post('/validatelogin', [UseregisterController::class, 'validatelogin'])->name('register.validatelogin');

