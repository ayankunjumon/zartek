<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
</style>
<link rel="stylesheet" href="{{ asset('style.css') }}">
</head>
<body>
<h4><a href="{{ route('myprofile') }}">My profile</a>
<a href="{{ route('mycontacts') }}">My Contacts</a>

<a href="{{ route('contact.create') }}">Add Contacts</a>

<a href="/">logout</a></h4>
<br><h2>
@yield('title')
</h2>
@yield('content')
</body></html>