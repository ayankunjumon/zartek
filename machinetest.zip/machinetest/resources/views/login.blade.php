<link rel="stylesheet" href="{{ asset('style.css') }}">
<div class="container"><form method="post" action="{{route('register.validatelogin')}}" enctype="multipart/form-data">@csrf

   User Name <input type="text" name="username"><br>
  Password <input type="password" name="password">
  <input type="submit" value="login" name="login"><input type="reset" value="cancel">
</form>
<a href="{{route('register.create')}}"> Register Now</a>
</div>