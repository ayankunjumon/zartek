<link rel="stylesheet" href="{{ asset('style.css') }}">
@if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif

<form method="post" action="{{route('register.store')}}" enctype="multipart/form-data" >@csrf
Name<input type="text" name="name" required value="{{ old('name') }}"><br>
Email<input type="email" name="email" required value="{{ old('email') }}"><br>
Phone Number<input type="text" name="phonenumber" value="{{ old('phonenumber') }}"><br>
Upload Your Photo<input type="file" name="upload"><br>
Username <input type="text" name="username" required value="{{ old('username') }}"><br>
Password<input type="password" name="password" id="password" required><br>
Retype Password<input type="password" name="repassword" id="repassword" required><br>
<input type="submit" id="btnSubmit">
<a href="/">Back to Login</a>
</form><script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
    $(function () {
        $("#btnSubmit").click(function () {
            var password = $("#password").val();
            var confirmPassword = $("#repassword").val();
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        });
    });
</script>
 