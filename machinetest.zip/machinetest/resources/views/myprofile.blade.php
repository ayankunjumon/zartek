@extends('usermaster')
@section('title','MY PROFILE')
@section('content')

<form method="post" action="{{route('register.store')}}" enctype="multipart/form-data">@csrf
   
    
    <img src="storage/{{$data[0]->profilepic}}" width="100px" height="100px">

    Name<input type="text" name="name" required value="{{ old('name',$data[0]->Name) }}" readonly><br>
Email<input type="email" name="email" required value="{{ old('email',$data[0]->Email) }}"readonly><br>
Phone Number<input type="text" name="phonenumber" value="{{ old('phonenumber',$data[0]->Phonenumber) }}"readonly><br>
</form>
@endsection